# Image directory
Your local image files should be stored in this folder.