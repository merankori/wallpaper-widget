# Video directory
Your local video files should be stored in this folder.